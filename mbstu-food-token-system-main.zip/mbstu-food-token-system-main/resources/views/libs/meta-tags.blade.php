	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta content="Money Laundering Prevention System" name="description" />
		<meta content="Themesbrand" name="author" />