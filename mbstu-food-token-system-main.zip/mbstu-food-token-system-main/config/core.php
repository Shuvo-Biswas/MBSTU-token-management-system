<?php

return [
    'image' => [
        'default' => [
        	'logo'   => '/assets/uploads/default/logo.png',
        	'logo2d' => '/assets/uploads/default/logo-2d.png',
        	'logo3d' => '/assets/uploads/default/logo-3d.jpg',
            'avatar' => '/assets/uploads/default/avatar.jpg',
            'cover'  => '/assets/uploads/default/cover.png',
        ]
    ],
];